package gui;

import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class Controller {
	@FXML
	private TabPane overview;
	@FXML
	private Tab homeTab;
	@FXML
	private Button endDay;
	@FXML
	private TextField dayNum;
	@FXML
	private TextField homeProgress;
	@FXML
	private TextField homeWeight;
	@FXML
	private TextField homeBMI;
	@FXML
	private TextField homeSleep;
	@FXML
	private TextField homeExcercise;
	@FXML
	private TextField homeDiet;
	@FXML
	private TextField homeWater;
	@FXML
	private ImageView healthBot;
	@FXML
	private TextArea botText;
	@FXML
	private Tab weightTab;
	@FXML
	private Button weightSet;
	@FXML
	private TextField weightText;
	@FXML
	private LineChart weightChart;
	@FXML
	private Tab bMITab;
	@FXML
	private LineChart bMIChart;
	@FXML
	private Tab sleepTab;
	@FXML
	private Button sleepSet;
	@FXML
	private TextField sleepText;
	@FXML
	private LineChart sleepChart;
	@FXML
	private Tab excerciseTab;
	@FXML
	private Button excerciseSet;
	@FXML
	private TextField excerciseText;
	@FXML
	private LineChart excerciseChart;
	@FXML
	private Tab dietTab;
	@FXML
	private Button dietSet;
	@FXML
	private TextField dietText;
	@FXML
	private LineChart dietChart;
	@FXML
	private Tab waterTab;
	@FXML
	private Button waterSet;
	@FXML
	private TextField waterText;
	@FXML
	private LineChart waterChart;
	@FXML
	private Tab goalsTab;
	@FXML
	private TextField goalWeight;
	@FXML
	private Button gwSet;
	@FXML
	private TextField goalBMI;
	@FXML
	private Button gBMISet;
	@FXML
	private TextField goalSleep;
	@FXML
	private Button gsSet;
	@FXML
	private TextField goalExcercise;
	@FXML
	private Button geSet;
	@FXML
	private TextField goalDiet;
	@FXML
	private Button gdSet;
	@FXML
	private TextField goalWater;
	@FXML
	private Button gwaterSet;


	@FXML
	private void initialize() {
	}

	private void moveText(String text, TextField inbox, TextField outbox) {
		inbox.setText(text + " " + outbox.getText());
	}
	@FXML
	public void setWeight() {
		moveText("Weight:", homeWeight, weightText);
		promptText("Weight:", weightText);
	}
	@FXML
	public void setSleep() {
		moveText("Sleep:", homeSleep, sleepText);
		promptText("Sleep:", sleepText);
	}
	@FXML
	public void setExcercise() {
		moveText("Excercise:", homeExcercise, excerciseText);
		promptText("Excercise:", excerciseText);
	}
	@FXML
	public void setDiet() {
		moveText("Diet:", homeDiet, dietText);
		promptText("Diet:", dietText);
	}
	@FXML
	public void setWater() {
		moveText("Water:", homeWater, waterText);
		promptText("Water:", waterText);
	}

	private void promptText(String text, TextField box) {
		String temp = box.getText();
		box.setText("");
		box.setPromptText(text + " " + temp);
	}
	@FXML
	public void setgWeight() {
		promptText("Weight:", goalWeight);
	}
	@FXML
	public void setgBMI() {
		promptText("BMI:", goalBMI);
	}
	@FXML
	public void setgSleep() {
		promptText("Sleep:", goalSleep);
	}
	@FXML
	public void setgExcercise() {
		promptText("Excercise:", goalExcercise);
	}
	@FXML
	public void setgDiet() {
		promptText("Diet:", goalDiet);
	}
	@FXML
	public void setgWater() {
		promptText("Water:", goalWater);
	}
}